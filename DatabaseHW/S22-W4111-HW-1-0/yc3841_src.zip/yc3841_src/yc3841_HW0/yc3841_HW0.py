
_my_uni = 'yc3841'


def t1():
    return _my_uni + " says Hello World"
